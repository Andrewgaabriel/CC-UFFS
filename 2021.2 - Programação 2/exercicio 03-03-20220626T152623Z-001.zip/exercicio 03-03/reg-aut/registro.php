<?php

    if(isset($_POST["nome"]) && isset($_POST["email"]) && isset($_POST["senha"])) {
        require 'db.php';
        $nome = $_POST["nome"];
        $email = $_POST["email"];
        $senha_pura = $_POST["senha"];
        
        $senha_cripto = password_hash($senha_pura, PASSWORD_DEFAULT);

        $comando = $db->prepare('INSERT INTO usuarios (nome, email, senha) VALUES (:nome, :email, :senha)');
        $comando->bindParam(':nome', $nome);
        $comando->bindParam(':email', $email);
        $comando->bindParam(':senha', $senha_cripto);
        $comando->execute();
    }

    require 'layout/index.html';


function insertInBD($nome, $email) {
    require 'db.php';
    $comando = $db->prepare('INSERT INTO usuarios (nome, email) VALUES (:nome, :email)');
    $comando->bindParam(':nome', $nome);
    $comando->bindParam(':email', $email);
    $comando->execute();
}

?>