<?php
    session_start();
    echo 'Welcome, ' . $_SESSION['nome'];
    echo '<p> Essa página apenas você pode acessar! </p>'


?>
