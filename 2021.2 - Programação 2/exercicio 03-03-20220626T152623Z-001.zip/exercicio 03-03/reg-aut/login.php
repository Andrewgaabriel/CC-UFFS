<?php

    if(isset($_POST["email"]) && isset($_POST["senha"])) {

        require 'db.php';

        $email = $_POST["email"];
        $senha = $_POST["senha"];

        $sql = $db->prepare("SELECT * FROM usuarios WHERE email = :email");
        $sql->bindParam(':email', $email);
        $sql->execute();
        $usuario = $sql->fetch();

        if(!usuario){
            echo 'Email não cadastrado! ';
        }

        if(password_verify($senha, $usuario['senha'])){

            session_start();
            $_SESSION['id'] = $usuario['id'];
            $_SESSION['nome'] = $usuario['nome'];
            $_SESSION['email'] = $usuario['email'];
            $_SESSION['senha'] = $usuario['senha'];

            require 'restrito.php';


        } else {
            echo '<h1>Senha incorreta! </h1>';
        }
    }


?>