<?php



    require 'db.php';

    $comando = $db->prepare('SELECT * FROM usuarios');
    $comando->execute();
    $resultado = $comando->fetchAll(PDO::FETCH_ASSOC);


    echo '<h1>Lista de usuários</h1>';
    
    //<a href="/exercicio 24-02/index.php"><input type="button" value="Voltar"></a>
    
    if (count($resultado) > 0) {
        echo '<ul>';
        foreach($resultado as $linha) {
            echo '<li> Id: '. $linha['id'] .' , Nome: ' . $linha['nome'] . ', E-mail: ' . $linha['email'] . '</li>';
        }
    } else {
        echo 'Nenhum usuário encontrado';
    }

    echo '</ul>';

    echo '
    <a href="/exercicio 24-02/index.php"><input type="button" value="Voltar"></a>
    
    ';
    



function printBD() {
    require 'db.php';
    $comando = $db->prepare('SELECT * FROM usuarios');
    $comando->execute();
    $resultado = $comando->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($resultado) > 0) {
        foreach($resultado as $linha) {
            echo 'Id: '. $linha['id'] .', Nome: ' . $linha['nome'] . ', E-mail: ' . $linha['email'] . '<br>';
        }
    } else {
        echo 'Nenhum usuário encontrado';
    }
}
 ?>