<?php

require_once 'db.php';
//require 'insert.php';
//require 'select.php';
//require 'update.php';




require 'layout/index.html';

    /*
    $nome = 'Andrew';
    $email= 'Andrew@gmail.com';
    insertInBD($nome, $email);

    $nome = 'Andrew2';
    $email= 'Andrew2@gmail.com';
    insertInBD($nome, $email);

    $nome = 'Andrew3';
    $email= 'Andrew3@gmail.com';
    insertInBD($nome, $email);

    printBD();

    echo '<br><br><br>';

    $id = '2';
    $nome = 'Updated-Andrew2';
    $email = 'Updated-Andrew2@gmail.com';
    updateBD($id, $nome, $email);
    */

?>