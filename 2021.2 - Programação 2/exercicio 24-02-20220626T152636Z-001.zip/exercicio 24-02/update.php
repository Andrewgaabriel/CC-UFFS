<?php

if(isset($_POST["nome"]) && isset($_POST["email"]) && isset($_POST["id"])) {
    require 'db.php';
    $id = $_POST["id"];
    $nome = $_POST["nome"];
    $email = $_POST["email"];

    $comando = $db->prepare('UPDATE usuarios SET nome = :nome, email = :email WHERE id = :id');
    $comando->bindParam(':id', $id);
    $comando->bindParam(':nome', $nome);
    $comando->bindParam(':email', $email);
    $comando->execute();
}

require 'layout/index.html';



function updateBD($id ,$nome, $email) {
    require 'db.php';
    $comando = $db->prepare('UPDATE usuarios SET nome = :nome, email = :email WHERE id = :id');
    $comando->bindParam(':id', $id);
    $comando->bindParam(':nome', $nome);
    $comando->bindParam(':email', $email);
    $comando->execute();
}
?>