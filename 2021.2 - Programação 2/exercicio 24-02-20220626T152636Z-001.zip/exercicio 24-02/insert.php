<?php

    if(isset($_POST["nome"]) && isset($_POST["email"])) {
        require 'db.php';
        $nome = $_POST["nome"];
        $email = $_POST["email"];

        $comando = $db->prepare('INSERT INTO usuarios (nome, email) VALUES (:nome, :email)');
        $comando->bindParam(':nome', $nome);
        $comando->bindParam(':email', $email);
        $comando->execute();
    }

    require 'layout/index.html';


function insertInBD($nome, $email) {
    require 'db.php';
    $comando = $db->prepare('INSERT INTO usuarios (nome, email) VALUES (:nome, :email)');
    $comando->bindParam(':nome', $nome);
    $comando->bindParam(':email', $email);
    $comando->execute();
}

?>