<?php


    require_once 'db.php';

    header('content-type:application/json');
    $dados = [];
    
    $dados['idade'] = 19;
    $dados['nome'] = 'Andrew';

    echo json_encode($dados);

